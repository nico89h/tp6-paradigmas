/* Vector.h */

#ifndef VECTOR_H_
#define VECTOR_H_
#include <iostream>

#include "IteradordeVector.h"
using namespace std;

typedef int item;
const item INDEFINIDO = -9999;
class IteradordeVector;
class Vector{
	item *arreglo;
	int max;
	bool reservarMemoria(int dim){
		this->arreglo = new item[dim];
			if(!this->arreglo){
				cerr<<"Memoria insuficiente"<<endl;
				return false;
			}
			else
				return true;
	}

public:
	Vector(){
		if (reservarMemoria(10))
				this->max=10;
			else
				this->max=0;
	}
	int getCapacidad(){
		return this->max;
	}
	item &operator[](int pos)const{
		if(0<=pos && pos<=this->max)
				return this->arreglo[pos];
			else{
				cout<<"Posici�n inv�lida"<<endl;
				return this->arreglo[0];
			}
	}
	friend class IteradordeVector;
};
#endif /* VECTOR_H_ */

