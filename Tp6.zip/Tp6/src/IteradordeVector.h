/*
 * IteradorDeVector.h
 *
 *  Created on: 5 dic. 2022
 *      Author: user
 */

#ifndef ITERADORDEVECTOR_H_
#define ITERADORDEVECTOR_H_

//inicio de la clase iterador de vector, que podra recorrer un vector
/*
 * 1)
a) Teniendo en cuenta la clase Vector(entero) implementada en el TP2 implemente
una clase IteradorDeVector que permita iterar sobre objetos del tipo Vector.
b) Reimplemente la función Pertenece para que utilice un objeto IteradorDeVector
para realizar su tarea. La función Pertenece es una función externa a la clase
Vector que, dados un Vector y un elemento retorna true si el elemento se
encuentra en el objeto Vector
c) Realice pruebas de la nueva implementación del tipo Vector y de la función
Pertenece.
 * */
#include "vector.h"W
class IteradordeVector {
private:
	const Vector &vector;
	int pos; //indica la posicion de el vector actual
public:
	IteradordeVector(Vector &vec);
	bool hayMasElementos();
	void avanzar();
	int elementoActual();
};

IteradordeVector::IteradordeVector(Vector &vec):vector(vec){
	this->pos=0;
}
bool IteradordeVector::hayMasElementos(){
	return this->pos<=(this->vector.max);
}
void IteradordeVector::avanzar(){
	if(this->hayMasElementos()){
		this->pos++;
	}
}
int IteradordeVector::elementoActual(){
		return this->vector[this->pos];
}

#endif /* ITERADORDEVECTOR_H_ */
