//============================================================================
// Name        : Tp6.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
/*
 * 1)
a) Teniendo en cuenta la clase Vector(entero) implementada en el TP2 implemente
una clase IteradorDeVector que permita iterar sobre objetos del tipo Vector.
b) Reimplemente la función Pertenece para que utilice un objeto IteradorDeVector
para realizar su tarea. La función Pertenece es una función externa a la clase
Vector que, dados un Vector y un elemento retorna true si el elemento se
encuentra en el objeto Vector
c) Realice pruebas de la nueva implementación del tipo Vector y de la función
Pertenece.
 *2) Teniendo en cuenta el ADT Vector(entero) implemente en C++:
a) Una Plantilla de Clase para el ADT Vector(item) y para el IteradorDeVector.
b) Una Plantilla de función para la función Pertenece.
c) Escriba un programa de prueba que utilice objetos Vector de distintos tipos (Ej:
Vector(int), Vector(Fecha), Vector(Libro), etc.) e invoque a la operación Pertenece.
NOTA: Tenga en cuenta que debe sobrecargar el operador de comparación == para poder
invocar la función Pertenece con los tipos definidos por el usuario.
3) Busque información (sintaxis, operaciones, etc.) sobre la Plantilla de Clase Vector en
la Standard Template Library (STL) de C++.
 * */
#include "vector.h"
#include "ioVector.h"
int main() {
	cout << "!!!Inicio de el tp6- iteradores y contenedores!!!" << endl; // prints !!!Hello World!!!

	Vector equis;
	cout<<"Ingrese los datos de el vector"<<endl;

	cin>>equis;


	//IteradorDeVector iterador(&equis);


	return 0;
}
